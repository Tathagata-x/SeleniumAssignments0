package fINEOS_Suite_EBEN;

import java.awt.AWTException;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.qa.actions.CreateBenefitActions;
import com.qa.base.PlaywrightTestBase;
import com.qa.utils.ExtentReportManager;
import com.qa.utils.TestUtils;
import com.qa.webELEMENTS.LoginPage;


/**
 * Test Name : validateFINEOSCrateBenefitFeature
 * Purpose   : To validate the FINEOS benefit creation feature via FINEOSActions.
 * Author    : 21-MAR-2025 by TathaB
 */

public class FINEOS_BenefitCreationAndValidation extends PlaywrightTestBase{
	
	
	private LoginPage login;
    private CreateBenefitActions cbActions;
    private SoftAssert softAssert;
    
    
    @BeforeMethod
    public void setUpTest() {
        if (page == null) {
            throw new IllegalStateException("❌ ERROR: Playwright `Page` is NULL in FINEOS_EBEN_TestCase");
        }
        System.out.println("✅ Page is initialized in FINEOS_EBEN_TestCase: " + page);
        softAssert = new SoftAssert();
        //ExtentReportManager.createTest("validate-FINEOS-BenefitCreationFeature");
        login = new LoginPage(page);
        cbActions = new CreateBenefitActions(page, softAssert);
    }
    @DataProvider(name = "ClaimBenefit")
    public Object[][] getFINEOSTestData() throws FileNotFoundException, IOException {
        return TestUtils.getTestData("ClaimBenefitDATA");
    }

    @Test(dataProvider = "ClaimBenefit")
    public void validateFINEOSBenefitCreationFeature(
            String usernameData, String passwordData, String firstNameData, String lastNameData, String tabName, String hours, String placeValue) throws InterruptedException, AWTException {
    	ExtentReportManager.createTest("validate-FINEOS-BenefitCreationFeature");
        login.navigateToUrl(usernameData, passwordData);
        cbActions.clickPartiesIcon()
        .getPartySearchHeader()
        .searchForParty(firstNameData, lastNameData)
        .selectSearchResult()
        .clickCasesTab()
        .openCaseByLabel()
        .navigateTo(tabName)
        .fillOccupationDetails(hours, placeValue)
        .navigateToClaimHub()
        .verifySTDPageDetails()
        .verifyAlertMessages()
        .tasksTab()
        .closeButtonClick()
        .clickOkButtonInFooter();
        softAssert.assertAll();
    }
}
      

