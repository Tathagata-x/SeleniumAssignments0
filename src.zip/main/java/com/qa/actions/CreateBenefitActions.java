package com.qa.actions;

import org.testng.asserts.SoftAssert;

import com.microsoft.playwright.Page;
import com.qa.utils.CommonPlaywrightActions;
import com.qa.webELEMENTS.FINEOSWebPageElements;

public class CreateBenefitActions extends FINEOSWebPageElements {

    private final CommonPlaywrightActions utils;
    private final SoftAssert softAssert;

    public CreateBenefitActions(Page page, SoftAssert softAssert) {
        super(page);
        if (page == null) {
            throw new IllegalArgumentException("❌ ERROR: Playwright `Page` is NULL in FINEOSActions");
        }
        this.softAssert = softAssert;
        this.utils = new CommonPlaywrightActions(page, softAssert);
        System.out.println("✅ `CommonPlaywrightActions` initialized in CreateBenefitActions.");
    }

    public CommonPlaywrightActions getUtils() {
        return utils;
    }

    // ------------------ Fluent Core Actions ------------------

    public CreateBenefitActions clickPartiesIcon() {
        utils.clickElement(getPartiesIcon(), "Parties ICON");
        return this;
    }

    public CreateBenefitActions getPartySearchHeader() {
        utils.assertElementDisplayed(getHeaderPartySearch(), "Search Header", softAssert);
        return this;
    }

    public CreateBenefitActions searchForParty(String firstName, String lastName) {
        utils.enterText(getInputFirstName(), firstName, "First Name");
        utils.enterText(getInputLastName(), lastName, "Last Name");
        utils.clickElement(getButtonPartySearch(), "Search Button");
        return this;
    }

    public CreateBenefitActions selectSearchResult() {
        utils.clickElement(getsearchPageOKButton(), "Search Result OK Button");
        return this;
    }
    public CreateBenefitActions clickCasesTab() {
        utils.clickElement(getCasesTab(), "Cases Tab (14Cases)");
        return this;

    }

    public CreateBenefitActions openCaseByLabel() {
        utils.clickElement(getButtonOpen(), "Open Case");
        return this;
    }



    public CreateBenefitActions navigateTo(String tabName) {
        utils.clickElement(page.getByText(tabName), "Tab: " + tabName);
        return this;
    }

    public CreateBenefitActions fillOccupationDetails(String hours, String placeValue) {
    	utils.scrollToElement(getButtonEditOccupationDetails(), "Scrolled to edit button for Occupation.");
        utils.clickElement(getButtonEditOccupationDetails(), "Edit Occupation Button");
        utils.enterText(getInputHoursWorkedPerWeek(), hours, "Hours/Week");
        utils.clickElement(getDropdownPlaceOfWork(), "Place of Work");
        utils.typeText(placeValue, "Work place. ");
        utils.pressKey("Enter", "Enter is pressed. ");
        utils.clickElement(getButtonSaveOccupation(), "Save Occupation");
        return this;
    }
    public CreateBenefitActions navigateToClaimHub() {
    	utils.clickElement(getTabClaimHub(), "Go to claim hub.");
    	utils.clickElement(getButtonClaimBenefit(), "Claim benefit.");
    	return this;
    }

	public CreateBenefitActions verifySTDPageDetails() {
		utils.assertElementDisplayed(getTextSTDBenefitVisible(), "STD Benefit Text Visible", softAssert);
		utils.assertElementDisplayed(getLinkSTDBenefit(), "STD Benefit Link Visible", softAssert);
		utils.assertElementDisplayed(getHeadingSTDBenefit(), "STD Benefit Heading Visible", softAssert);
		utils.clickElement(getHeadingSTDBenefit(), "STD Tab");
		
		return this;
	}
	
	public CreateBenefitActions verifyAlertMessages() {
		String SuppressionText = "Suppress message!";
		utils.waitForElementToDisplay(getRedAlert());
		if(getTextApprovalMessage().isVisible()) {
			utils.assertElementDisplayed(getTextApprovalMessage(), "Approval Warning is visible", softAssert);
			utils.clickElement(getButtonBenefitApprovalEdit(), "+ is clicked for Benefit Approval Details.");
			utils.clickElement(getCalendarIconDateAllDataCollected(), "Date all data collected Calender button.");
			utils.clickElement(getTodayButton(), "Current date is fine. ");
            utils.hoverElement(getCalendarIconDateAllDataCollected(), "UI Action");
            utils.pressKey("ArrowLeft", "ArrowLeft is pressed. ");
			utils.clickElement(getButtonFooterOk(), "Ok Button from footer section is clicked. ");
		}
        utils.waitForElementToDisplay(getRedAlert());
        utils.clickElement(getRedAlert(), "Alerts");
		if(getTextEligibilityMemberEffective().isVisible()){
			utils.assertElementDisplayed(getTextEligibilityMemberEffective(), "Effective Date of coverage Info is visible", softAssert);
			utils.clickElement(getLinkSuppressValidationEligibility(), "Suppressing Eligibility validation Alert.");
			utils.enterText(getInputDescription(), SuppressionText, "Input.");
			utils.pressKey("Tab", "Tab is pressed. ");
			utils.pressKey("Enter", "Enter is pressed. ");
		}
		utils.waitForElementToDisplay(getRedAlert());
        utils.clickElement(getRedAlert(), "Alerts");
		if(getTextInformationPremiumPaid().isVisible()){
			utils.assertElementDisplayed(getTextInformationPremiumPaid(), "Premium Paid Info is visible", softAssert);
			utils.clickElement(getLinkSuppressValidationInformational(), "Suppressing informational Alert.");
			utils.enterText(getInputDescription(), SuppressionText, "Input.");
			utils.pressKey("Tab", "Tab is pressed. ");
			utils.pressKey("Enter", "Enter is pressed. ");
		}
		return this;
	}
    public CreateBenefitActions tasksTab() {
        utils.clickElement(getTasksTab(), "Task tab");
        return this;
    }
    public CreateBenefitActions closeButtonClick() {
        utils.clickElement(getCloseButton(), "Close button");
        return this;
    }
    public CreateBenefitActions clickOkButtonInFooter() {
        utils.clickElement(getOkButtonInFooter(), "OK button in footer");
        return this;
    }
}
