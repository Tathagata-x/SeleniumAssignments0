package com.qa.actions;

import org.testng.asserts.SoftAssert;

import com.microsoft.playwright.Page;
import com.qa.utils.CommonPlaywrightActions;
import com.qa.webELEMENTS.FINEOSWebPageElements;

public class PaymentSetupActions extends FINEOSWebPageElements {
    private final CommonPlaywrightActions utils;
    private final SoftAssert softAssert;

    public PaymentSetupActions(Page page, SoftAssert softAssert) {
        super(page);
        if (page == null) {
            throw new IllegalArgumentException("❌ ERROR: Playwright `Page` is NULL in FINEOSActions");
        }
        this.softAssert = softAssert;
        this.utils = new CommonPlaywrightActions(page, softAssert);
        System.out.println("✅ `CommonPlaywrightActions` initialized in PaymentSetupActions.");
    }

    public CommonPlaywrightActions getUtils() {
        return utils;
    }
        // ------------------ Fluent Core Actions ------------------

        public PaymentSetupActions clickPartiesIcon() {
            utils.clickElement(getPartiesIcon(), "Parties ICON");
            return this;
        }
    
        public PaymentSetupActions getPartySearchHeader() {
            utils.assertElementDisplayed(getHeaderPartySearch(), "Search Header", softAssert);
            return this;
        }
    
        public PaymentSetupActions searchForParty(String firstName, String lastName) {
            utils.enterText(getInputFirstName(), firstName, "First Name");
            utils.enterText(getInputLastName(), lastName, "Last Name");
            utils.clickElement(getButtonPartySearch(), "Search Button");
            return this;
        }
    
        public PaymentSetupActions selectSearchResult() {
            utils.clickElement(getsearchPageOKButton(), "Search Result OK Button");
            return this;
        }
        public PaymentSetupActions clickCasesTab() {
            utils.clickElement(getCasesTab(), "Cases Tab (14Cases)");
            return this;
    
        }
    
        public PaymentSetupActions openCaseByLabel() {
            utils.clickElement(getButtonOpen(), "Open Case");
            return this;
        }
    
        public PaymentSetupActions navigateTo() {
            utils.clickElement(getTabPayments(), "Payment tab.");
            return this;
        }
    
}
