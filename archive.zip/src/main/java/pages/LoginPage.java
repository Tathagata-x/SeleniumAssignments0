package pages;

import org.testng.asserts.SoftAssert;

import com.microsoft.playwright.Page;

import utils.CommonPlaywrightActions;
import webELEMENTS.Locators;

public class LoginPage extends Locators{
	private final Page page;
    private final CommonPlaywrightActions utils;

    public LoginPage(Page page, SoftAssert softAssert) {
        super(page);
        this.page = page;
        this.utils = new CommonPlaywrightActions(page, softAssert); // ✅ now correctly initialized
    }

    public void login(String username, String password) {
    	String URL = "https://pdsinfosysliveopsdemo2.service-now.com/";
    	page.navigate(URL);
        utils.enterText(getUserName(), username, "Username input");
        utils.enterText(getPassword(), password, "Password Input");
        utils.clickElement(getLoginButton(), "Login button.");
    }
}
