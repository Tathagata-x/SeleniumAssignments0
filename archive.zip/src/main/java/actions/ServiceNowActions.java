package actions;

import org.testng.asserts.SoftAssert;
import com.microsoft.playwright.Page;
import utils.CommonPlaywrightActions;
import webELEMENTS.Locators;

public class ServiceNowActions extends Locators {

    private final CommonPlaywrightActions utils;
    private final SoftAssert softAssert;

    public ServiceNowActions(Page page, SoftAssert softAssert) {
        super(page); // Pass `Page` to parent class

        if (page == null) {
            throw new IllegalArgumentException("❌ ERROR: Playwright `Page` is NULL in ServiceNowActions");
        }
        this.softAssert = softAssert;
        this.utils = new CommonPlaywrightActions(page, this.softAssert);
        System.out.println("✅ `CommonPlaywrightActions` initialized in ServiceNowActions.");
    }

    public CommonPlaywrightActions getUtils() {
        return utils;
    }

    public ServiceNowActions clickAllLabel() {
        utils.clickElement(getAllLabel(), "All Label");
        return this;
    }

    public ServiceNowActions refreshMenu() {
        utils.clickElement(getRefreshMenu(), "Refresh Menu");
        return this;
    }

    public ServiceNowActions filterChange(String filterText) {
        utils.clickElement(getFilter(), "Filter");
        utils.enterText(getFilter(), filterText, "Filter");
        return this;
    }

    public ServiceNowActions clickCreateNew() {
        utils.clickElement(getCreateNew(), "Create New");
        return this;
    }

    public ServiceNowActions fillConfigurationItem(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getConfigItem(), text, "Configuration Item");
        utils.pressKey("ArrowDown", "Configuration Item");
        utils.pressKey("Enter", "Configuration Item");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillShortDescription(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getShortDescription(), text, "Short Description");
        utils.pressKey("Tab", "Short Description");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillDescription(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getDescription(), text, "Description");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillJustification(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getJustification(), text, "Justification");
        utils.pressKey("Tab", "Justification");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillImplementationPlan(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getImplementationPlan(), text, "Implementation Plan");
        utils.pressKey("Tab", "Implementation Plan");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillRiskAndImpactAnalysis(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getRiskAndImpactAnalysis(), text, "Risk and Impact Analysis");
        utils.pressKey("Tab", "Risk and Impact Analysis");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillBackoutPlan(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getBackoutPlan(), text, "Backout Plan");
        utils.pressKey("Tab", "Backout Plan");
        utils.switchToDefaultContent();
        return this;
    }

    public ServiceNowActions fillTestPlan(String text) {
        utils.switchToFrame(getChangeRequestIframe(), "Change Request Iframe");
        utils.enterText(getTestPlan(), text, "Test Plan");
        utils.switchToDefaultContent();
        return this;
    }
}