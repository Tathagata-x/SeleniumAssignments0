package webELEMENTS;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;

public class Locators {
	protected Page page;
	protected final Locator body;
	protected final Locator userName;
	protected final Locator password;
	protected final Locator loginButton;
	protected final Locator allLabel;
	protected final Locator refreshMenu;
	protected final Locator filter;
	protected final Locator createNew;
	protected final Locator changeRequestIframe;
	protected final Locator configItem;
	protected final Locator shortDescription;
	protected final Locator description;
	protected final Locator justification;
	protected final Locator implementationPlan;
	protected final Locator riskAndImpactAnalysis;
	protected final Locator backoutPlan;
	protected final Locator testPlan;

    public Locators(Page page) {
    	this.page = page;
        body = page.locator("body");
        userName = page.getByLabel("User name");
        password = page.getByLabel("Password", new Page.GetByLabelOptions().setExact(true));
        loginButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Log in"));
        allLabel = page.getByLabel("All", new Page.GetByLabelOptions().setExact(true));
        refreshMenu = page.locator("#refresh-menu");
        filter = page.getByPlaceholder("Filter");
        createNew = page.getByLabel("Create New 1 of");
        changeRequestIframe = page.locator("iframe[name=\"gsft_main\"]");
        configItem = changeRequestIframe.contentFrame().getByLabel("Configuration item", new FrameLocator.GetByLabelOptions().setExact(true));
        shortDescription = changeRequestIframe.contentFrame().getByLabel("Short description");
        description = changeRequestIframe.contentFrame().getByLabel("Description", new FrameLocator.GetByLabelOptions().setExact(true));
        justification = changeRequestIframe.contentFrame().getByLabel("Justification");
        implementationPlan = changeRequestIframe.contentFrame().getByLabel("Implementation plan");
        riskAndImpactAnalysis = changeRequestIframe.contentFrame().getByLabel("Risk and impact analysis");
        backoutPlan = changeRequestIframe.contentFrame().getByLabel("Backout plan");
        testPlan = changeRequestIframe.contentFrame().getByLabel("Test plan");
    }

    public Locator getBody() {
        return body;
    }

    public Locator getUserName() {
        return userName;
    }

    public Locator getPassword() {
        return password;
    }

    public Locator getLoginButton() {
        return loginButton;
    }

    public Locator getAllLabel() {
        return allLabel;
    }

    public Locator getRefreshMenu() {
        return refreshMenu;
    }

    public Locator getFilter() {
        return filter;
    }

    public Locator getCreateNew() {
        return createNew;
    }

    public Locator getChangeRequestIframe() {
        return changeRequestIframe;
    }

    public Locator getConfigItem() {
        return configItem;
    }

    public Locator getShortDescription() {
        return shortDescription;
    }

    public Locator getDescription() {
        return description;
    }

    public Locator getJustification() {
        return justification;
    }

    public Locator getImplementationPlan() {
        return implementationPlan;
    }

    public Locator getRiskAndImpactAnalysis() {
        return riskAndImpactAnalysis;
    }

    public Locator getBackoutPlan() {
        return backoutPlan;
    }

    public Locator getTestPlan() {
        return testPlan;
    }
}