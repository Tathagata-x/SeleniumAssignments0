package testCase;

import java.awt.AWTException;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.LoginPage;

import actions.ServiceNowActions;
import base.PlaywrightTestBase;
import utils.ExtentReportManager;
import utils.TestUtils;

public class SNOW_TestCase extends PlaywrightTestBase {
	private ServiceNowActions snow;
	private SoftAssert softAssert;
	private LoginPage login;

	@BeforeMethod
	public void setUpTest() {
		if (page == null) {
			throw new IllegalStateException("ERROR: Playwright `Page` is NULL in SNOW_TestCase");
		}

		System.out.println("Page is initialized in SNOW_TestCase: " + page);
		softAssert = new SoftAssert();
		ExtentReportManager.createTest("validate EMERGENCY CHANGE Feature");
		login = new LoginPage(page, softAssert);
		snow = new ServiceNowActions(page, softAssert);
	}

	@DataProvider(name = "LoginDATA")
	public Object[][] getTestData() throws FileNotFoundException, IOException {
		return TestUtils.getTestData("LoginDATA");
	}

	@Test(dataProvider = "LoginDATA")
	public void validateEmergencyChangeFeature(String username, String password, String configItemText,
			String shortDescriptionText, String descriptionText, String justificationText,
			String implementationPlanText, String riskAndImpactAnalysisText, String backoutPlanText,
			String testPlanText) throws InterruptedException, AWTException {

		login.login(username, password);
		snow.clickAllLabel().refreshMenu().filterChange("change").clickCreateNew().fillConfigurationItem(configItemText)
				.fillShortDescription(shortDescriptionText).fillDescription(descriptionText)
				.fillJustification(justificationText).fillImplementationPlan(implementationPlanText)
				.fillRiskAndImpactAnalysis(riskAndImpactAnalysisText).fillBackoutPlan(backoutPlanText)
				.fillTestPlan(testPlanText);
		softAssert.assertAll();
	}

}
